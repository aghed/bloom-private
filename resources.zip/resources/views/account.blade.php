@extends("layout.partials.master")


@section("maincontent")
    <div class="container">
        <div class="row text-center">
            <h2><b>MY ACCOUNT</b></h2>
        </div>
    </div>

    <div class="container ">
        <div class="main-box">

            <div class="row">
                <div class="col-md-2">
                    <div class="nav-list">
                        <div class="nav-list-item">
                            <a href="#profile">PROFILE</a>
                        </div>
                        <div class="nav-list-item">
                            <a href="#orderhistory">ORDER HISTORY</a>
                        </div>
                        <div class="nav-list-item">
                            <a href="#subsciptions">SUBSCRIPTIONS</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-10 account-content">
                    <div id="profile">
                        <div class="user-details-box">
                            <div class="user-details-col">
                                <div class="user-details-col-item">
                                    <p class="user-details-label"><b>FULL NAME</b></p>
                                    <p class="user-details-value"><b>TARIQ ABU SAMRA</b></p>
                                </div>
                                <div class="user-details-col-item">
                                    <p class="user-details-label"><b>MOBILE NUMBER</b></p>
                                    <p class="user-details-value"><b>+971 52 1234567</b></p>
                                </div>

                            </div>
                            <div class="user-details-col">
                                <div class="user-details-col-item">
                                    <p class="user-details-label"><b>EMAIL</b></p>
                                    <p class="user-details-value"><b>TARIQ@DUBAIMN.COM</b></p>
                                </div>
                                <div class="user-details-col-item">
                                    <p class="user-details-label"><b>GENDER</b></p>
                                    <p class="user-details-value"><b>MALE</b></p>
                                </div>

                            </div>
                        </div>
                        <div class="user-details-ops">
                            <button type="button" class="btn btn-default user-details-op">EDIT</button>
                            <button type="button" class="btn btn-default user-details-op">CHANGE PASSWORD</button>
                        </div>
                    </div>
                    <div id="orderhistory">
                        <div class="orders-list">
                            <div class="orders-list-item">
                                <p style="text-align: center; padding-top: 20px"><b>ORDER</b></p>
                                <p class="order-list-item-id">AE-99119</p>
                                <div class="table-responsive">
                                    <table class="table borderless">
                                        <thead>
                                        <tr>
                                            <th>ITEMS</th>
                                            <th>STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>RED ROSE BOX<br>SQUARE-LARGE</td>
                                            <td>DELIVERED</td>

                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="orders-list-item">
                                <p style="text-align: center; padding-top: 20px"><b>ORDER</b></p>
                                <p class="order-list-item-id">AE-99119</p>
                                <div class="table-responsive">
                                    <table class="table borderless">
                                        <thead>
                                        <tr>
                                            <th>ITEMS</th>
                                            <th>STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>RED ROSE BOX<br>SQUARE-LARGE</td>
                                            <td>DELIVERED</td>

                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="orders-list-item">
                                <p style="text-align: center; padding-top: 20px"><b>ORDER</b></p>
                                <p class="order-list-item-id">AE-99119</p>
                                <div class="table-responsive">
                                    <table class="table borderless">
                                        <thead>
                                        <tr>
                                            <th>ITEMS</th>
                                            <th>STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>RED ROSE BOX<br>SQUARE-LARGE</td>
                                            <td>DELIVERED</td>

                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>


@endsection


@section("mystyle")
    <style>
        .container>div{
            letter-spacing: 2px;
            font-family: "Brandon Grotesque"
        }

        .main-box{
            border: 1px solid #bababa;
            margin-top: 50px;
            margin-bottom: 150px;
        }

        .nav-list{
            background-color: #f1f1f1;

        }

        .nav-list-item{
            text-align: center;
            padding-top: 40px;
            padding-bottom: 40px;

        }

        .nav-list-item a{
            font-size: 11px;
            letter-spacing: 2px;
            color: #0f0f0f;
        }

        .user-details-box{
            height: 100%;

        }

        .user-details-col{
            display: inline-block;
        }

        .user-details-label{
            color: #0f0f0f;
        }

        .user-details-value{
            color: #8c8c8c;
        }

        .user-details-col-item{
            font-size: 11px;
            letter-spacing: 2px;
            margin-left: 40px;
            margin-top: 40px;
        }

        .user-details-ops{
            margin-left: 40px;
            margin-top: 40px;
        }
        .user-details-op{
            margin-right: 20px;
            border-radius: 0px;
            background-color: #7ce2c4;
            color: #0f0f0f;
            border-color: #7ce2c4;
            padding-left: 30px;
            padding-right: 30px;
            font-size: 11px;
            letter-spacing: 2px;
        }

        .borderless td, .borderless th{
            border: none !important;
        }
        .borderless td{
            font-size: 10px !important;
        }
        .borderless{
            margin-left: 10px;
            margin-right: 10px;
            margin-top: 20px;
        }

        .orders-list{
            margin-top: 20px;
            margin-bottom: 20px;
            height: inherit;
        }

        .orders-list-item{
            height: 100%;
            font-size: 11px;
            letter-spacing: 2px;
            border:  1px solid #bababa;
            margin-left: 30px;
            display: inline-block;

        }

        table{
            height: 100px;
            width: auto;
        }

        .order-list-item-id{
            font-weight: bold;
            text-align: center;
            margin-top: -10px;
        }

        #orderhistory{
            display: none;
            height: inherit;
        }

        #orderhistory, #profile{
            position: absolute;
        }

        .account-content{
            position: relative;

        }


    </style>

@endsection

@section("myscript")

    <script>
        $(document).ready(function(){
            var current = "#profile";
            $('.nav-list a').click(function(){
                var dest = $(this).attr('href');
                $(current).fadeOut();
                $(dest).fadeIn();
                current = dest;

                return false;
            });
        });
    </script>


@endsection