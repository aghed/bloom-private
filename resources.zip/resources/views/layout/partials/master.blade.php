<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('bower_components/bootstrap/dist/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="{{asset('bower_components/normalize-css/normalize.css')}}">
    <link rel="stylesheet" href="{{asset('css/fonty/stylesheet.css')}}">
    <link rel="stylesheet" href="{{asset('bower_components/slick-carousel/slick/slick.css')}}">
    {{--<link rel="stylesheet" href="{{asset('bower_components/slick-carousel/slick/slick-theme.css')}}">--}}

    <link rel="stylesheet" id="size-stylesheet" href="{{asset('css/app.css')}}">
    @section("mystyle")
    @show
    <title>title</title>
    <style>

    </style>
</head>
<body style="font-family:'Brandon Grotesque' !important">


@include("layout.partials.nav")





@section("maincontent")
@show




@include("layout.partials.footer_2")



<script src="{{asset("bower_components/jquery/dist/jquery.min.js")}}"></script>
<script src="{{asset("bower_components/bootstrap/dist/js/bootstrap.min.js")}}"></script>
<script src="{{asset("bower_components/slick-carousel/slick/slick.js")}}"></script>
<script>
    $(document).ready(function () {
//

        $('.login-btn').hover(function () {
            $('.login-dropdown-menu').css({display:'block'});
            $(".login-dropdown-menu").hover(function(){}, function () {
                $(this).css({display: 'none'});
            });
        });

        $('.currency-dropdown-menu li a').on('click',function () {
            $('currency-dropdown-menu li a').removeClass('selected-item');
            $(this).addClass('selected-item');
        });
        $('.currency-dropdown-menu a').click(function () {
            $('.currency-dropdown-menu a').removeClass('selected-item');
            $(this).addClass('selected-item');
        })








        //slick configure

        $('.prd-slick').slick({
            prevArrow:'.left-arrow',
            nextArrow:'.right-arrow',
            slidesToShow: 4,
            respondTo:this
        });





        // Exuexte when the windows is Mobile
        if($(window).width() >= 0 && $(window).width() <= 500 ) {

        }
    });
</script>
@section("myscript")
@show

</body>
</html>