<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{asset('bower_components/normalize-css/normalize.css')}}">
    <title>Document</title>
    <style>
        *{
            margin: 0px;
            padding: 0px;
        }
    </style>
</head>
<body style="background: #f6f6f6">
<div style="width: 30%;
    text-align: center;
    margin: 5% auto;">
    <img src="{{asset('assets/images/logo.png')}}" alt="">

</div>

</body>
</html>


